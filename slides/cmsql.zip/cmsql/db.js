var mongoose=require('mongoose');
mongoose.connect("mongodb://localhost:27017/training")

var courseSchema=mongoose.Schema({
	name: String,
    description: String,
    level: String
})

exports.Course=mongoose.model('Course',courseSchema,'courses');

