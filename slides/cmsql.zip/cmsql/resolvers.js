var gql=require('graphql');
var db=require('./db')

const resolvers = {
  Query: {
    allCourses: () => {
      return new Promise((resolve,reject)=>{
      	db.Course.find({},(err,courses)=>{
      		if(err) reject(err);
      		resolve(courses);
      	})
      })
    },
    allStudents: () => {
      return [];
    }
  },
  Mutation: {
    createCourse: (_, { name, description, level }) => {
      return new Promise((resolve,reject)=>{
      	var newCourse=new db.Course({
      		name,
      		description,
      		level
      	});
      	newCourse.save((err,course)=>{
      		if(err) reject(err);
      		resolve(course);
      	})
      })
    },
    updateCourse: (_, { id, name, description, level }) => {
      const input = { id, name, description, level };
      return input;
    },
    deleteCourse: (_, { id }) => {
      const input = { id };
      return new Promise((resolve,reject)=>{
      	db.Course.findByIdAndRemove(id,(err,course)=>{
          if(err) reject(err);
      		resolve(course);
        })
      })
    },
    createStudent: (_, { firstName, lastName, active, coursesIds }) => {
      
      const input = {
        id,
        firstName,
        lastName,
        active,
        courses
      };

      
    
      return input;
    },
    updateStudent: (_, { id, firstName, lastName, active, coursesIds }) => {
      let input = { id, firstName, lastName, active };
      input.courses = [];
      
      return input;
    },
    deleteStudent: (_, { id }) => {
      return id;
    }
  }
};

module.exports=resolvers;

